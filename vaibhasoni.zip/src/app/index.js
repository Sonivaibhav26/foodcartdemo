import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import Grid from '@material-ui/core/Grid';
import axios from 'axios';

import Appbar from './../appbar';
import Navigation from './../navigation';
import Menu from './../menu';
import Cart from './../cart'

const styles = theme => ({
    root: {
        flexGrow: 1,
        height: '100%',
        zIndex: 1,
        overflow: 'hidden',
        position: 'relative',
        display: 'flex',
    },
    content: {
        flexGrow: 1,
        backgroundColor: theme.palette.background.default,
        padding: theme.spacing.unit * 3,
        minWidth: 0, // So the Typography noWrap works
    },
    toolbar: theme.mixins.toolbar,
});

class App extends Component {
    constructor(props) {
        super(props);
        this.state = {
            items: [],
            categories: [],
            cart: [],
        }
        this.add = this.add.bind(this);
        this.remove = this.remove.bind(this);
        this.clear = this.clear.bind(this);
    }

    add(item) {
        let newCart = [];
        for (let index = 0; index < this.state.cart.length; index++) {

            const element = this.state.cart[index];
            if (element.name === item.name) {
                element.qty += 1;
                newCart.push(element);
            } else {
                newCart.push(element);
            }

            if (element.name !== item.name && index === this.state.cart.length - 1) {
                newCart.push({ name: item.name, qty: 1, price: item.price });
            }
        }


        if (this.state.cart.length === 0) {
            newCart.push({ name: item.name, qty: 1, price: item.price });
        }

        this.setState({ cart: newCart });
    };

    remove(item) {
        let newCart = [];
        for (let index = 0; index < this.state.cart.length; index++) {
            const element = this.state.cart[index];
            if (element.name === item.name && element.qty > 1) {
                element.qty -= 1;
                newCart.push(element);
            } else if (element.name !== item.name) {
                newCart.push(element);
            }

        }

        this.setState({ cart: newCart });
    };

    clear() {
        this.setState({ cart: [] });
    };

    componentDidMount() {
        axios.get(`https://thesmartq.firebaseio.com/menu.json`)
            .then(res => {
                this.setState({
                    categories: res.data
                        .map(value => value.category)
                        .reduce((x, y) => x.includes(y) ? x : [...x, y], []),
                    items: res.data
                });
            })
    }

    render() {
        const { classes } = this.props;

        return (
            <div className={classes.root}>
                <Appbar />
                <Grid container >
                    <Grid item xs>
                        <Navigation categories={this.state.categories} />
                    </Grid>
                    <Grid item xs={6}>
                        <main className={classes.content}>
                            <div className={classes.toolbar} />
                            <Menu categories={this.state.categories} items={this.state.items} add={this.add} remove={this.remove} cart={this.state.cart} />
                        </main>
                    </Grid>
                    <Grid item xs>
                        <div className={classes.toolbar} />
                        <Cart cart={this.state.cart} clear={this.clear} />
                    </Grid>
                </Grid>
            </div>
        );
    }
}

App.propTypes = {
    classes: PropTypes.object.isRequired,
};

export default withStyles(styles)(App);