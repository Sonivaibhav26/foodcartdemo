import React, { Component } from 'react';
import './App.css';
import App from './app';

class Application extends Component {
  render() {
    return (
      <App />
    );
  }
}

export default Application;
